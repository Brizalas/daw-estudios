package entornos.ejercicio1;

/**
 * Clase que representa un Cliente con nombre, edad y DNI.
 */
public class Cliente {
    private String nombre;
    private int edad;
    private String dni;

    /**
     * Constructor para inicializar un cliente.
     * @param nombre Nombre del cliente.
     * @param edad Edad del cliente.
     * @param dni DNI del cliente.
     */
    public Cliente(String nombre, int edad, String dni) {
        this.nombre = nombre;
        this.edad = edad;
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getDni() {
        return dni;
    }
}