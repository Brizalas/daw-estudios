package entornos.ejercicio1;

/**
 * Clase de prueba para demostrar el funcionamiento de Pedido y Cliente.
 */
public class Main {
    public static void main(String[] args) {
        // Crear un nuevo cliente
        Cliente cliente = new Cliente("Cristian", 35, "12345678A");

        // Crear un pedido con ese cliente
        Pedido pedido = new Pedido(1, cliente);

        // Mostrar los datos por consola
        System.out.println("Pedido ID: " + pedido.getId());
        System.out.println("Cliente: " + pedido.getCliente().getNombre());
        System.out.println("Edad: " + pedido.getCliente().getEdad());
        System.out.println("DNI: " + pedido.getCliente().getDni());
    }
}