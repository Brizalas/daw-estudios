package entornos.ejercicio1;

/**
 * Clase que representa un Pedido, que contiene un ID y un Cliente asociado.
 */
public class Pedido {
    private int id;
    private Cliente cliente;

    /**
     * Constructor de la clase Pedido.
     * @param id Identificador del pedido.
     * @param cliente Cliente que realiza el pedido.
     */
    public Pedido(int id, Cliente cliente) {
        this.id = id;
        this.cliente = cliente;
    }

    public int getId() {
        return id;
    }

    public Cliente getCliente() {
        return cliente;
    }
}