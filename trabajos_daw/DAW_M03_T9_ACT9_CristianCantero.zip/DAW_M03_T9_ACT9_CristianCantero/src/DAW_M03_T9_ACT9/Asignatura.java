package DAW_M03_T9_ACT9;

/**
 *
 * @author cristiancantero
 */
public abstract class Asignatura {
    private String nombre;
    private int creditos;
   

    public Asignatura() {
        
    }

    public Asignatura(String nombre, int creditos) {
        this.nombre = nombre;
        this.creditos = creditos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }
    
    public abstract int calcularPrecioTotal();
    public abstract void mostrarInformacion();
    
    
}
 